﻿using UnityEngine;

namespace FusionExamples.Utility
{
	public class ObjectPoolRoot : MonoBehaviour
	{
	}
}